var APP_DATA = {
  "scenes": [
    {
      "id": "0-",
      "name": "Сыроварня",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "yaw": -0.9169760310888453,
        "pitch": 0.06919511085878582,
        "fov": 1.3474042771833745
      },
      "linkHotspots": [
        {
          "yaw": -1.2966114563515543,
          "pitch": 0.0828583717642637,
          "rotation": 0,
          "target": "1-360-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-360-2",
      "name": "360 2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.244561177665533,
          "pitch": 0.06360915992574334,
          "rotation": 0,
          "target": "0-"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
